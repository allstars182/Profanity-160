#ifndef HPP_PRECOMP
#define HPP_PRECOMP

#include "types.hpp"

extern point g_precomp[8160];

#endif /* HPP_PRECOMP */